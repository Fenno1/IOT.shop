<!doctype html>
<html>
<head>
<title>Facebook-2</title>
    <meta charset="utf-8">
    <meta name="description" content="Blog">
    <meta name="keywords" content="blog">
    <meta name="author" content="Siebe">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="./BLOG/CSS/style.css" rel="stylesheet" type="text/css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Lato&display=swap" rel="stylesheet">
</head>

<body>
	<header>
        
        <div class="header">
            <h1>top</h1>
            <p>bodem</p>
        </div>

    
        <div class="navbar">
            
            <div>
            <a class="links-nav" href="home.php">home</a>
           

         </div>
            <div>
              <a class="links-nav" href="login.php">Logout</a>
            </div>
        </div>
        
        


    </header>