<title>Facebook-2</title>
    <meta charset="utf-8">
    <meta name="description" content="Blog">
    <meta name="keywords" content="blog, posts">
    <meta name="author" content="Siebe">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="./BLOG/CSS/style.css" rel="stylesheet" type="text/css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Lato&display=swap" rel="stylesheet">
</head>

<body>
	<header>
        
        <div class="header">
            <h1>Facebook 2</h1>
            <p>Facebook 1 is er niks bij </p>
        </div>
	<div class="container-fluid justify-content-end">
		<ul class="navbar-nav">		
		<li class="nav-item">
		<a class="nav-link" href="#">Login</a>
		</li>
			<li class="nav-item">
		<a class="nav-link" href="register.php">Register</a>
		</li>
			
			</ul>
		</div>
</nav>
	</header>
	 
	

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.6.0/dist/umd/popper.min.js" integrity="sha384-KsvD1yqQ1/1+IA7gi3P0tyJcT3vR+NdBTt13hSJ2lnve8agRGXTTyNaBYmCR/Nwi" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.min.js" integrity="sha384-nsg8ua9HAw1y0W1btsyWgBklPnCUAFLuTMS2G72MMONqmOymq585AcH49TLBQObG" crossorigin="anonymous"></script>
</body>
</html>